from setuptools import setup, find_packages

setup(
    name='common-dibbs',
    version='0.10',
    packages=find_packages(),
)
