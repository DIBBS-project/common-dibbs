from setuptools import setup, find_packages

setup(
    name='common-dibbs',
    version='0.12',
    packages=find_packages(),
)
