from setuptools import setup

setup(
    name='common-dibbs',
    version='0.11',
    packages=['common_dibbs.auth', 'common_dibbs.config', 'common_dibbs.clients', 'common_dibbs.clients.ar_client',
              'common_dibbs.clients.cas_client', 'common_dibbs.clients.om_client', 'common_dibbs.clients.or_client'],
)
